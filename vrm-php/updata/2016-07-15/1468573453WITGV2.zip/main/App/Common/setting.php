<?php
$sysrow = array();
$sysrow["web_name"] = "全景通";
$sysrow["upload_type_all"] = "jpg|jpeg|gif|png|bmp|mp3|wma|flv|swf|mp4|m4v|zip";
$sysrow["upload_type_image"] = "jpg|jpeg|gif|png";
$sysrow["upload_type_audio"] = "mp3|wma";
$sysrow["upload_type_video"] = "wma|flv|swf|mp4|m4v";
$sysrow["upload_size"] = "100";
?>
