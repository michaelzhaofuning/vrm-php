<?php

class ConfigAction extends MemberAction {

    function index() {
        if (I("post.dopost") == "save") {
            $pano_id = I("post.pano_id");

            $panowhere = array(
                "id" => $pano_id,
                "member_id" => $this->member_id
            );
            $title = trim(I('post.title'));
            $is_ipad_view = intval(I('post.is_ipad_view'));
            $is_littleplanet_view = intval(I('post.is_littleplanet_view'));
            $cursor_open = intval(I("post.cursor_open"));
            $cursor_id = intval(I('post.cursor_id'));
            $openautorate = intval(I("post.openautorate"));
            $autoratewaittime = intval(I("post.autoratewaittime"));
            $autoratespeed = intval(I("post.autoratespeed"));
            $autorateaccel = intval(I("post.autorateaccel"));
            $openautonext = intval(I('post.openautonext'));
            $autonextpass = intval(I('post.autonextpass'));
            $thumbwidth = intval(I('post.thumbwidth'));
            $thumbheight = intval(I('post.thumbheight'));

            if ($title == "") {
                $this->error("标题不能为空！");
                exit();
            }

            $data = array(
                "title" => $title,
                "member_id" => $this->member_id,
                "is_ipad_view" => $is_ipad_view,
                "is_littleplanet_view" => $is_littleplanet_view,
                "cursor_open" => $cursor_open,
                "cursor_id" => $cursor_id,
                "openautorate" => $openautorate,
                "autoratewaittime" => $autoratewaittime,
                "autoratespeed" => $autoratespeed,
                "autorateaccel" => $autorateaccel,
                "openautonext" => $openautonext,
                "autonextpass" => $autonextpass,
                'thumbwidth' => $thumbwidth,
                'thumbheight' => $thumbheight
            );
            M("Pano")->where($panowhere)->save($data);
            $this->success("修改成功！", U("index", array("pano_id" => $pano_id)));
            exit();
        }

        $pano_id = I("get.pano_id");
        $this->assign('pano_id', $pano_id);

        $panowhere = array(
            "id" => $pano_id,
            "member_id" => $this->member_id
        );
        $panorow = M("Pano")->where($panowhere)->find();
        $this->assign('panorow', $panorow);

        $syscursorwhere = array(
            "type" => "system"
        );
        $syscursorrow = M("Cursor")->where($syscursorwhere)->select();
        $this->assign("syscursorrow", $syscursorrow);

        $selfcursorwhere = array(
            "type" => "self",
            "member_id" => $this->member_id
        );
        $selfcursorrow = M("Cursor")->where($selfcursorwhere)->select();
        $this->assign("selfcursorrow", $selfcursorrow);

        $mid = $this->member_id;
            $this->assign('mid', $mid);

        $this->display();
    }

}

?>
