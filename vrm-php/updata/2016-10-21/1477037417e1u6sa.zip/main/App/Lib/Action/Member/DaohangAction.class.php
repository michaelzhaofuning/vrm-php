<?php

class DaohangAction extends MemberAction {
    public function index() {
        $pano_id = I("get.pano_id");
        $this->assign('pano_id', $pano_id);

        $member_id = $this->member_id;
        $this->assign("member_id", $member_id);

        $panorow = D("Pano")->GetOne($pano_id, $this->member_id);
        $this->assign('panorow', $panorow);
		$count = M("pano_nav")->where(array("pano_id"=>$pano_id))->count();
		if($count<=0)
		{
			$data = array();
			$data['navname'] = "默认导航";
			$data['color'] = "#FFFFFF";
			$data['overcolor'] = "#FFFFFF";
			$data['pano_id'] = $pano_id;
			$data['navbgid'] = 4;
			$data['ox'] = 20;
			$data['oy'] = 0;
			$result = M("pano_nav")->data($data)->add();
			if($result)
			{
				M("pano_nav")->data(array("listorder"=>$result))->save();
			}
		}

		$panonav = M("pano_nav")->where(array("pano_id"=>$pano_id))->find();
		$navbginfo = M("navbg")->where(array("id"=>$panonav['navbgid']))->find();
		$this->assign('panonav', $panonav);
		$this->assign('navbginfo', $navbginfo);

		if (I("post.dopost") == "save")
		{
			$data = array();
			$opennav = I("post.opennav");
			$data['color'] = I("post.color");
			$data['overcolor'] = I("post.overcolor");
			$data['navbgid'] = I("post.navbgid");
			$data['ox'] = I("post.ox");
			$data['oy'] = I("post.oy");
			if($data['navbgid']==1) $data['oy']=9;
			M("pano_nav")->where(array("pano_id"=>$pano_id))->save($data);
			M("Pano")->where(array("id"=>$pano_id))->save(array("opennav"=>$opennav));
			$this->success("保存成功！", U("index", array("pano_id" => $pano_id)));
			exit;
		}
        $this->display();
    }
	public function selNavbg()
	{
		$list = M("navbg")->where(array("member_id"=>0))->select();
		//print_r($list);
		$this->assign('list', $list);
		$this->display();
	}
	public function navlist()
	{
		$pano_id = I("get.pano_id");
		$this->assign('pano_id', $pano_id);
		$list = M("pano_nav")->where(array("pano_id"=>$pano_id))->order("listorder asc")->select();
		$this->assign('list', $list);
		$this->display();
	}
	
	public function edit()
	{
		$id = I("get.id");
		$navinfo = M("pano_nav")->where(array("id"=>$id))->find();
		if (I("post.dopost") == "save" && !empty($id))
		{
			$content = $_POST["content"];
			$opentype = I("post.opentype");
			$data = array();
			$data['navname'] = I("post.navname");
			$data['listorder'] = I("post.listorder");
			$data['opentype'] = $opentype;
			$data['iframewidth'] = I("post.iframewidth");
			$data['iframeheight'] = I("post.iframeheight");
			if($opentype==1){
				$data['content'] = $content;				
			}
			elseif($opentype==2)
			{
				$data['linkurl'] = I("post.linkurl");
			}
			M("pano_nav")->where(array("id"=>$id))->save($data);
			$this->success("保存成功！", U("navlist", array("pano_id" => $navinfo['pano_id'])));
			exit;
		}

		$this->assign('navinfo', $navinfo);
		$this->assign('pano_id', $navinfo['pano_id']);
		$this->display();
	}

	public function del()
	{
		$id = I("get.id");
		$pano_id = I("get.pano_id");
		if(!empty($id))
		{
			M("pano_nav")->where("id='$id'")->delete();
			$this->success("删除成功！", U("navlist", array("pano_id" => $pano_id)));
		}
	}
}
?>
