<?php
    $ConfigAction = array(
        "mysql_have_do" =>1,
    );
    $File_Del = array();
?>
